class MenuItem {
    id: number;
    parentId: number;
    active: boolean;
    children: Array<MenuItem>;
}

export default MenuItem;
